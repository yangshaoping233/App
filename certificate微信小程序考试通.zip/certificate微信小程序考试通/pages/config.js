exports.IMG = {
    URL: "http://img.kaocat.com/",
    STYLE: "@!compress"
};

exports.HOST = "https://wx.kaocat.com/";
